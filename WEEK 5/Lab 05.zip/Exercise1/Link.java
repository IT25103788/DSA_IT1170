package LabSheet05.Exercise1;

class Link {
    int studentId;
    int marks;
    Link next;

    public Link(int studentId, int marks) {
        this.studentId = studentId;
        this.marks = marks;
        this.next = null;
    }

    public void displayLink() {
        System.out.println("ID: " + studentId + ", Marks: " + marks);
    }
}




