package LabSheet05.Exercise1;

class LinkedList {
    private Link first;

    public LinkedList() {
        first = null;
    }

    public boolean isEmpty() {
        return first == null;
    }

    // Insert new student record at the beginning
    public void insertFirst(int id, int marks) {
        Link newLink = new Link(id, marks);
        newLink.next = first;
        first = newLink;
    }

    // Find a student by id
    public Link find(int key) {
        Link current = first;
        while (current != null) {
            if (current.studentId == key) {
                return current;
            }
            current = current.next;
        }
        return null; // not found
    }

    // Insert new student record after the node with matching key
    public void insertAfter(int key, int id, int marks) {
        Link target = find(key);
        if (target == null) {
            System.out.println("Student ID " + key + " not found. Cannot insert after.");
            return;
        }
        Link newLink = new Link(id, marks);
        newLink.next = target.next;
        target.next = newLink;
    }

    // Delete the first element
    public Link deleteFirst() {
        if (isEmpty()) {
            System.out.println("List is empty. Cannot delete.");
            return null;
        }
        Link temp = first;
        first = first.next;
        return temp;
    }

    // Delete a student by id
    public Link delete(int key) {
        if (isEmpty()) {
            System.out.println("List is empty. Cannot delete.");
            return null;
        }

        // Key is at the first node
        if (first.studentId == key) {
            return deleteFirst();
        }

        // Key is in the middle or end
        Link previous = first;
        Link current = first.next;
        while (current != null) {
            if (current.studentId == key) {
                previous.next = current.next;
                return current;
            }
            previous = current;
            current = current.next;
        }

        System.out.println("Student ID " + key + " not found.");
        return null;
    }

    // Display all elements in the list
    public void displayList() {
        Link current = first;
        while (current != null) {
            current.displayLink();
            current = current.next;
        }
    }
}
