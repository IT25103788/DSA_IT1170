package LabSheet05.Exercise1;

public class MainLink1 {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        // Insert students
        list.insertFirst(103, 75);
        list.insertFirst(101, 85);
        list.insertFirst(102, 90);

        System.out.println("List after insertions:");
        list.displayList();

        // Delete student with ID 102
        list.delete(102);
        System.out.println("List after deleting ID 102:");
        list.displayList();

        // Delete first element
        list.deleteFirst();
        System.out.println("List after deleting first element:");
        list.displayList();
    }
}
