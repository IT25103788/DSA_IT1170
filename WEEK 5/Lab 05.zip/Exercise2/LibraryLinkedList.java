package LabSheet05.Exercise2;

class LibraryLinkedList {
    private BookLink first;

    public LibraryLinkedList() {
        first = null;
    }

    public boolean isEmpty() {
        return first == null;
    }

    // Insert new book record at the beginning
    public void insertFirst(int id, String title, int copies) {
        BookLink newLink = new BookLink(id, title, copies);
        newLink.next = first;
        first = newLink;
    }

    // Find a book by id
    public BookLink find(int key) {
        BookLink current = first;
        while (current != null) {
            if (current.bookId == key) {
                return current;
            }
            current = current.next;
        }
        return null; // not found
    }

    // Insert new book record after the node with matching key
    public void insertAfter(int key, int id, String title, int copies) {
        BookLink target = find(key);
        if (target == null) {
            System.out.println("Book ID " + key + " not found. Cannot insert after.");
            return;
        }
        BookLink newLink = new BookLink(id, title, copies);
        newLink.next = target.next;
        target.next = newLink;
    }

    // Delete the first element
    public BookLink deleteFirst() {
        if (isEmpty()) {
            System.out.println("List is empty. Cannot delete.");
            return null;
        }
        BookLink temp = first;
        first = first.next;
        return temp;
    }

    // Delete a book by id
    public BookLink delete(int key) {
        if (isEmpty()) {
            System.out.println("List is empty. Cannot delete.");
            return null;
        }

        // Key is at the first node
        if (first.bookId == key) {
            return deleteFirst();
        }

        // Key is in the middle or end
        BookLink previous = first;
        BookLink current = first.next;
        while (current != null) {
            if (current.bookId == key) {
                previous.next = current.next;
                return current;
            }
            previous = current;
            current = current.next;
        }

        System.out.println("Book ID " + key + " not found.");
        return null;
    }

    // Display all books in the list
    public void displayList() {
        BookLink current = first;
        while (current != null) {
            current.displayLink();
            current = current.next;
        }
    }
}
