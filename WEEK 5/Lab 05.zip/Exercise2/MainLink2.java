package LabSheet05.Exercise2;

public class MainLink2 {
    public static void main(String[] args) {

        LibraryLinkedList library = new LibraryLinkedList();

        // Insert Initial Books
        library.insertFirst(3, "Welcome", 8);
        library.insertFirst(1, "Hello", 15);
        library.insertFirst(2, "World", 4);  // becomes the new head

        System.out.println("List after insertions:");
        library.displayList();

        // Add a New Book After a Specific Book (after book ID 1)
        library.insertAfter(1, 4, "Java Basics", 5);

        // Find a Book
        System.out.println("\nFinding Book ID 1:");
        BookLink found = library.find(1);
        if (found != null) {
            System.out.print("Found -> ");
            found.displayLink();
        } else {
            System.out.println("Book not found.");
        }

        // Remove a Book
        library.delete(2);
        System.out.println("\nList after deleting ID 102:");
        library.displayList();

        // Delete the First Book
        library.deleteFirst();
        System.out.println("\nList after deleting first element:");
        library.displayList();

        // Display Available Books
        System.out.println("\nAvailable Books:");
        library.displayList();
    }
}
