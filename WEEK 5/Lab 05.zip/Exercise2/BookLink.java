package LabSheet05.Exercise2;

class BookLink {
    int bookId;
    String bookTitle;
    int copies;
    BookLink next;

    public BookLink(int bookId, String bookTitle, int copies) {
        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.copies = copies;
        this.next = null;
    }

    public void displayLink() {
        System.out.println("ID: " + bookId + ", Title: " + bookTitle + ", Copies: " + copies);
    }
}

